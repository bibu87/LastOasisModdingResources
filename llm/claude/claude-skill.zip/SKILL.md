---
name: last-oasis-modkit
description: |
  Guide users building mods for the survival MMO Last Oasis using the official Last Oasis Modkit (Unreal Engine 4.25.4, Donkey Crew). Use this skill ANY time the user mentions Last Oasis modding, the Modkit, the SDKTest branch, "Mist" content, walkers (custom or modded), Last Oasis Workshop mods, MyRealm configuration with mods, the bibu87 LastOasisModdingResources repo, or asks how to build, edit, package, publish, or troubleshoot a Last Oasis mod — even if they don't say the word "modkit" explicitly. Trigger for skins, retextures, balance tweaks, new items/walkers/creatures/maps, total conversions, server-side mod hosting, Steam Workshop publishing, Blueprint API questions about Last Oasis classes, packaging errors, or "why won't my mod load." Covers four workflows — end-to-end onboarding, reference Q&A, project coaching, and troubleshooting. Knowledge is a snapshot from April 2026 and may lag the live Modkit; flag uncertainty when stakes are high and direct users to the official Discord.
---

# Last Oasis Modkit Companion

Last Oasis is a nomadic survival MMO by Donkey Crew. The official Modkit (free, distributed via the Epic Games Store) was released April 2024, with Modkit 2.0 shipping alongside Season 6 changes. It is built on **Unreal Engine 4.25.4** — be careful: some community video tutorials say UE5; they are wrong. Mods are tested via the **SDKTest** Steam branch and published to the **Steam Workshop**.

The user is at least Blueprint-comfortable in Unreal. Skip beginner Unreal hand-holding unless they signal otherwise. Adapt depth to how they ask: terse questions get terse answers, walkthrough questions get structured guidance.

## Step 0: Identify the workflow

Almost every Last Oasis modding request falls into one of four workflows. Pick the right one before answering — the references/ files are organized this way:

| Signal | Workflow | Reference file |
|---|---|---|
| "I want to start modding," "how do I install," "first mod" | **Onboarding** (install → first edit → publish) | `references/onboarding.md` |
| "How does X work," "what does Y class do," "is there an event for Z" | **Reference Q&A** (look up Modkit/UE specifics) | `references/reference.md` |
| "I'm building [a specific mod]," "help me design," multi-session work | **Project coaching** (architecture, scope, plan) | `references/project_coaching.md` |
| "It crashes," "won't package," "doesn't load," "EAC error" | **Troubleshooting** | `references/troubleshooting.md` |

Read the relevant reference file before responding in depth. If the request spans multiple workflows (common — e.g., "I'm new and want to build an airship mod"), read more than one. Do not dump all reference content into the response; use it to inform a focused answer.

## Always-on behaviors

**Be willing to write code.** When a Blueprint node graph, C++ snippet, INI config, `Start.bat` flag, or Python editor script would help, draft it. Use sensible defaults, comment intent, and flag what the user must verify in their own editor (asset paths, exact node names, etc.). Always note that the user must test in the Modkit's Play-In-Editor before packaging.

**Cite the Blueprint API JSON when relevant.** The community resource repo at `https://github.com/bibu87/LastOasisModdingResources` ships a file `data/LastOasis_APIs.json` listing every Blueprint asset in the Modkit and its exposed functions/members, plus `data/widget_bp_functions.txt` for Widget Blueprints (UMG). When the user asks "does class X expose function Y" or "which Blueprint handles Z," tell them this file is the canonical lookup, give them the path, and — if they paste content from it — answer from that. Do not invent function signatures. If you don't know whether a function exists, say so and point them at the JSON.

**Keep "Mist" terminology straight.** Last Oasis's UE project is named `Mist` (legacy from development). Content lives under `Mist/Content/`. Mods on a server install to `Mist/Content/Mods/`. Don't confuse this with the company name (Donkey Crew) or the studio's other projects.

**Adapt depth to the user.** Read their language: "how do I open the modkit" → patient, walk them through. "What's the parent class of BP_WalkerBase" → one-liner with the answer. Don't lecture experienced users; don't assume context with new ones.

**Knowledge is dated.** This skill snapshot is April 2026. The Modkit is actively updated alongside Season 6+. When the user asks about anything that smells volatile (recent patch behavior, new Blueprint classes, broken-in-the-last-update issues), tell them to verify in the official Discord at `https://discord.gg/lastoasis` — that is the canonical support venue and the Modkit docs live there.

## Canonical resources (mention by URL, not from memory)

These are the resources to direct users to, organized by what they're trying to do:

- **Modkit download**: `https://store.epicgames.com/en-US/p/last-oasis-modkit` (Epic, free)
- **Official Modkit Drive folder** (assets, samples, docs): `https://drive.google.com/drive/folders/1QqS5Z32g07FLpTja2g6oCUJ3YeJnqND1`
- **Official Discord** (support + pinned docs): `https://discord.gg/lastoasis`
- **Steam Workshop hub**: `https://steamcommunity.com/app/903950/workshop/`
- **MyRealm portal** (for adding mods to a realm): `https://myrealm.lastoasis.gg/`
- **Community resources repo** (Blueprint API JSON, Python extraction scripts, link index): `https://github.com/bibu87/LastOasisModdingResources`
- **Modkit announcement** (context for what was shipped): `https://store.steampowered.com/news/app/903950/view/4192362393727227355`
- **Fandom wiki** (game data — modules, walkers, items): `https://lastoasis.fandom.com/wiki/Last_Oasis_Wiki`

The `references/resources.md` file has the full annotated list, including video tutorials, hosting providers, and community forums. Read it when the user asks "where do I learn X" or "what's the best resource for Y."

## Things that surprise newcomers — surface these proactively

- Modkit is on **Epic**, but the modded **game** branch is on **Steam** (`SDKTest` beta branch). Both are required for the round-trip workflow.
- Modkit is **UE 4.25.4**. Don't grab the latest Unreal — projects are version-locked.
- Mods on dedicated servers go in `Mist/Content/Mods/` after Workshop download, AND must be listed in the realm's `Mods=...` Gameplay setting on MyRealm.
- **Easy Anti-Cheat is incompatible with modded servers.** Server `Start.bat` must disable EAC. (Hosting-provider control panels usually expose a toggle; self-hosters edit the launch line.)
- The Season 6 / Modkit 2.0 merge **broke many existing mods** — if the user is updating an old mod, tell them to expect breakage and verify against the current Modkit.

## When to push back / clarify

If the user asks for something that looks fundamentally outside what the Modkit supports (e.g., changes to the master server, anti-cheat bypass on official servers, decompiling shipped game DLLs), name the limit clearly and suggest the supported alternative (typically: run a private modded server). Do not help with anti-cheat circumvention on official servers.

If a request is ambiguous between "I want to build a mod that does X" and "I want X added to the base game," ask which one. The answer changes everything.
